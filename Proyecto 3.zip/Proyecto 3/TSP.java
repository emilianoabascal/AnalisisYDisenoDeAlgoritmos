/**
 * This file contains a recursive implementation of the TSP problem using 
 * dynamic programming. The main idea is that since we need to do all n!
 * permutations of nodes to find the optimal solution that caching the results 
 * of sub paths can improve performance.
 *
 * For example, if one permutation is: '... D A B C' then later when we need
 * to compute the value of the permutation '... E B A C' we should already have 
 * cached the answer for the subgraph containing the nodes {A, B, C}.
 * 
 * Time Complexity: O(n^2 * 2^n)
 * Space Complexity: O(n * 2^n)
 *
 * @author Steven & Felix Halim, William Fiset, Micah Stairs
 */
//package com.williamfiset.algorithms.graphtheory;

import java.util.*;
import java.io.*;
import java.lang.*;

public class TSP {
	
	private final int N;
	private final int START_NODE;
	private final int FINISHED_STATE;
	public static int weight[][];
	public static int n;
	public static int path[];
	public static int cost;
	public static int value_x[];
	public static int value_y[];
	private double[][] distance;
	private double minTourCost = Double.POSITIVE_INFINITY;
	private static double[][] distanceMatrix;
	private List<Integer> tour = new ArrayList<>();
	private boolean ranSolver = false;
	
	public static void TSPDP(String archivo)throws FileNotFoundException{//Funcion para leer un archivo e introducirlo a un arreglo.
		int V, E;
		double x1,y1,x2,y2,x,y;
		Scanner in = new Scanner(new File(archivo));
		V = in.nextInt();//agremamos la primera letra 
		double[ ][ ] aryNumbers = new double[V][2];
		double[ ][ ] costos = new double[V][V];
		for (int i = 0; i < V; i++) //llenamos el grafo 
		{
			for (int j = 0; j < 2; j++) //llenamos el grafo 
			{
				aryNumbers[i][j] = in.nextDouble();
			}
		}
		for (int i = 0; i < V; i++) //llenamos el grafo 
		{
			x1=aryNumbers[i][0];
			y1=aryNumbers[i][1];
			for (int j = 0; j < V; j++){ //llenamos el grafo
				x2=aryNumbers[j][0];
				y2=aryNumbers[j][1];
				x=	x2-x1;	
				y=	y2-y1;	
				costos[i][j]=Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2));		
					
			}
		}	
		int startNode = 0;
		TSP solver = new TSP(startNode, costos);
		System.out.println("Usando Programacion Dinamica:");
		System.out.println("Camino: " + solver.getTour());

		System.out.println("Costo Del Camino: " + solver.getTourCost());
	}
		
		
	public static double distanceCalculator(double x1, double y1, double x2, double y2){
		double distance = (Math.pow(x1-x2, 2) + Math.pow(y2-y1, 2));
		return Math.sqrt(distance);
	}
	public TSP(double[][] distance) {
		this(0, distance);
	}

	public TSP(int startNode, double[][] distance) {
		
		this.distance = distance;
		N = distance.length;
		START_NODE = startNode;
		
		// Validate inputs.
		if (N <= 2) throw new IllegalStateException("TSP on 0, 1 or 2 nodes doesn't make sense.");
		if (N != distance[0].length) throw new IllegalArgumentException("Matrix must be square (N x N)");
		if (START_NODE < 0 || START_NODE >= N) throw new IllegalArgumentException("Starting node must be: 0 <= startNode < N");

		// The finished state is when the finished state mask has all bits are set to
		// one (meaning all the nodes have been visited).
		FINISHED_STATE = (1 << N) - 1;
	}

	// Returns the optimal tour for the traveling salesman problem.
	public List<Integer> getTour() {
		if (!ranSolver) solve();
		return tour;
	}

	// Returns the minimal tour cost.
	public double getTourCost() {
		if (!ranSolver) solve();
		return minTourCost;
	}

	public void solve() {

		// Run the solver    
		int state = 1 << START_NODE;
		Double[][] memo = new Double[N][1 << N];
		Integer[][] prev = new Integer[N][1 << N];
		minTourCost = tsp(START_NODE, state, memo, prev);
		
		// Regenerate path
		int index = START_NODE;
		while (true) {
			tour.add(index);
			Integer nextIndex = prev[index][state];
			if (nextIndex == null) break;
			int nextState = state | (1 << nextIndex);
			state = nextState;
			index = nextIndex;
		}
		tour.add(START_NODE);
		ranSolver = true;
	}

	private double tsp(int i, int state, Double[][] memo, Integer[][] prev) {
		
		// Done this tour. Return cost of going back to start node.
		if (state == FINISHED_STATE) return distance[i][START_NODE];
		
		// Return cached answer if already computed.
		if (memo[i][state] != null) return memo[i][state];
		
		double minCost = Double.POSITIVE_INFINITY;
		int index = -1;
		for (int next = 0; next < N; next++) {
			
			// Skip if the next node has already been visited.
			if ((state & (1 << next)) != 0) continue;
			
			int nextState = state | (1 << next);
			double newCost = distance[i][next] + tsp(next, nextState, memo, prev);

			if (newCost < minCost) {
				minCost = newCost;
				index = next;
			}
		}
		
		prev[i][state] = index;
		return memo[i][state] = minCost;
	}
	public static void BruteForce(String file){
		Scanner s = new Scanner (System.in);
			//Looks for the file to create the arrays
			int[] Array = readFiles(file);
			n = Array[0];
			weight = new int[n][n];
			value_x = new int[n];
			value_y = new int[n];
			path = new int[n-1];
			int k = 0;
			for (int i=1; i<Array.length; i = i+2){
				value_x[k] = Array[i];
				k++;
			}
			int d = 0;
			for (int i=2; i<Array.length; i = i+2){
				value_y[d] = Array[i];
				d++;
			}
			for (int i = 0; i < n; i ++){
				for (int j = 0; j < n; j++){
					double x = Math.pow((value_x[j] - value_x[i]),2);int x_ = (int) x;
					double y = Math.pow((value_y[j] - value_y[i]),2);
					int y_ = (int) y;
					double r = Math.sqrt( x_ + y_ );
					int w = (int) r;
					weight[i][j] = w;
				}
			}
			System.out.println();
			evaluate();
	}
	public static int[] readFiles(String file){
		try{
			File f = new File(file);
			Scanner s = new Scanner(f);
			int ctr = 0;
			while (s.hasNextInt()){
				ctr++;
				s.nextInt();
			}
			int[] Array = new int [ctr];
			Scanner s1 = new Scanner(f);
			for (int i = 0; i < Array.length; i++)
			Array[i] = s1.nextInt();
			return Array;
		}
		catch(Exception e){
		return null;
		}
	}
	public static int getCost(int currentCity, int input[], int size){
		if (size == 0)
		return weight[currentCity][0];
		int min=999999;
		int minIndex = 0;
		int setToCost[] = new int[n-1];
		for (int i = 0; i < size; i++){
			int k = 0; //initializate new set
			for (int j = 0; j < size; j++){
				if(input[i] != input[j]){
				setToCost[k++] = input[j];
				}
			}
			int tmp = getCost(input[i], setToCost, size-1);
			if((weight[currentCity][input[i]]+tmp)<min){
			min = weight[currentCity][input[i]]+tmp;
			minIndex = input[i];
			}
		}
		return min;
	}
	public static int getMin(int currentCity, int input[], int size){
		if(size == 0)
		return weight[currentCity][0];
		int min = 999999;
		int minIndex = 0;
		int setToCost[] = new int [n-1];
		for (int i = 0; i < size; i++){ //consider each node of input set
			int k = 0; //initializate new set
			for (int j = 0; j < size; j++){
				if(input[i] != input[j]){
					setToCost[k++] = input[j];
				}
			}
			int tmp = getCost(input[i], setToCost, size-1);
			if((weight[currentCity][input[i]]+tmp) < min){
				min = weight[currentCity][input[i]]+tmp;
				minIndex = input[i];
			}
		}
		return minIndex;
}
	public static void evaluate(){
		int trySet[] = new int [n-1];
		for(int i = 1; i < n; i++)
			trySet[i-1] = i;
			cost = getCost(0, trySet, n-1);
			pathContructor();
	}
	public static void pathContructor(){
		int lastSet[]=new int[n-1];
		int nextSet[]=new int[n-2];
		for(int i=1;i<n;i++)
			lastSet[i-1]=i;
			int size=n-1;
			path[0]=getMin(0,lastSet,size);
			
		for(int i=1;i<n-1;i++){
			int k=0;
			for(int j=0;j< size;j++){
				if(path[i-1]!=lastSet[j])
					nextSet[k++]=lastSet[j];
		}
		--size;
		path[i]=getMin(path[i-1],nextSet,size);
		for(int j=0;j<size;j++)
			lastSet[j]=nextSet[j];
		}
		printResult();
	}


	public static void printResult(){
		System.out.println();
		System.out.println("Usando Fuerza Bruta:");
		System.out.print("Camino: [0, ");
		for(int i = 0; i < n-1; i++){
			System.out.print((path[i] )+", ");
		}
		System.out.println("0]");
		System.out.println("Costo del Camino: " + cost);
	}

	public static void main(String[] args) throws FileNotFoundException{
		long startTime = System.currentTimeMillis();
		BruteForce("smallMap.txt");	
		long endTime = System.currentTimeMillis();
		long totalTime = endTime - startTime;
		System.out.println("Milisegundos: " + totalTime);
		System.out.println();
		
		startTime = System.currentTimeMillis();
		TSPDP("smallMap.txt");
		endTime = System.currentTimeMillis();
		totalTime = endTime - startTime;
		System.out.println("Milisegundos: " + totalTime);
			
	}
	
}